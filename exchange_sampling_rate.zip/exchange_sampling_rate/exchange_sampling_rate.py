import gradio as gr
import os
import soundfile as sf
import numpy as np
import resampy

def convert_sample_rate(directory_path, target_sr):
    target_sr = int(target_sr)
    responses = []
    for filename in os.listdir(directory_path):
        if filename.endswith(".wav") or filename.endswith(".flac") or filename.endswith(".mp3"):
            filepath = os.path.join(directory_path, filename)
            data, sr = sf.read(filepath, dtype='float32')
            
            if sr != target_sr:
                data_resampled = resampy.resample(data, sr, target_sr)
                save_path = os.path.join(directory_path, f"resampled_{filename}")
                sf.write(save_path, data_resampled, target_sr)
                responses.append(f"Converted and saved {filename} to {target_sr}Hz.")
            else:
                responses.append(f"{filename} is already at {target_sr}Hz.")

    return "\n".join(responses)

interface = gr.Interface(
    fn=convert_sample_rate, 
    inputs=[
        gr.Textbox(lines=1, label="Enter Directory Path"),
        gr.Dropdown(choices=["32000", "40000", "48000"], label="Target Sampling Rate")
    ],
    outputs="text",
    live=False,  
    submit_button="送信",  # 送信ボタンのテキストを変更
    allow_flagging="never"  # フラグするボタンを非表示にします
)

interface.launch()
